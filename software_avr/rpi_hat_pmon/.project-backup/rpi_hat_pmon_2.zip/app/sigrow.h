/*
 * sigrow.h
 *
 * Created: 03/07/2022 10:44:18
 *  Author: David Michaeli / CaribouLabs LTD
 */ 


#ifndef SIGROW_H_
#define SIGROW_H_

void init_system_data(uint32_t* mcu_type, uint8_t *uuid);


#endif /* SIGROW_H_ */