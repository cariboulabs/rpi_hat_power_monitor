/*
 * button_gesture.c
 *
 * Created: 19/07/2022 12:14:07
 *  Author: David Michaeli / CaribouLabs LTD
 */

#include "button_gesture.h"

//================================================================
static void button_gesture_new_state(button_gesture_st* dev, button_gesture_state_machine_en nextState)
{
	dev->_lastState = dev->_state;
	dev->_state = nextState;
}

//================================================================
void button_gesture_init(button_gesture_st* dev, bool active_state)
{
	dev->_state = button_gesture_state_OCS_INIT;
	dev->_lastState = button_gesture_state_OCS_INIT;
	dev->_currentTimeTicks = 0;
	dev->_paramClickFunc = NULL;
	dev->_function_context = NULL;
	dev->_maxClicks = 1;
	dev->_debounceTicks = 50;
	dev->_clickTicks = 400;
	dev->_pressTicks = 800;
	dev->_startTime = 0;
	dev->_nClicks = 0;
	dev->_activeState = active_state;
}

//================================================================
void button_gesture_reset(button_gesture_st* dev)
{
	dev->_state = button_gesture_state_OCS_INIT;
	dev->_lastState = button_gesture_state_OCS_INIT;
	dev->_nClicks = 0;
	dev->_startTime = 0;
}

//================================================================
void button_gesture_attachClick(button_gesture_st* dev, button_gesture_cb newFunction, void *parameter)
{
	dev->_paramClickFunc = newFunction;
	dev->_function_context = parameter;
}

//================================================================
void button_gesture_set_debounce_ticks(button_gesture_st* dev, int ticks)
{
	dev->_debounceTicks = ticks;
}

//================================================================
void button_gesture_set_click_ticks(button_gesture_st* dev, int ticks)
{
	dev->_clickTicks = ticks;
}

//================================================================
void button_gesture_set_press_ticks(button_gesture_st* dev, int ticks)
{
	dev->_pressTicks  = ticks;	
}

//================================================================
void button_gesture_tick_level(button_gesture_st* dev, bool b_level)
{
	bool activeLevel = (b_level == dev->_activeState);
	dev->_currentTimeTicks ++;
	unsigned long now = dev->_currentTimeTicks;
	unsigned long waitTime = (now - dev->_startTime);

	// Implementation of the state machine
	switch (dev->_state) 
	{
		//---------------------------------------
		case button_gesture_state_OCS_INIT:
			// waiting for level to become active.
			if (activeLevel) 
			{
				button_gesture_new_state(dev, button_gesture_state_OCS_DOWN);
				dev->_startTime = now; // remember starting time
				dev->_nClicks = 0;
			} // if
		break;

	//---------------------------------------
	case button_gesture_state_OCS_DOWN:
		// waiting for level to become inactive.

		if ((!activeLevel) && (waitTime < dev->_debounceTicks)) 
		{
			// button was released to quickly so I assume some bouncing.
			button_gesture_new_state(dev, dev->_lastState);
		} 
		else if (!activeLevel) 
		{
			button_gesture_new_state(dev, button_gesture_state_OCS_UP);
			dev->_startTime = now; // remember starting time
		} 
		else if ((activeLevel) && (waitTime > dev->_pressTicks))
		{
			if (dev->_paramClickFunc) dev->_paramClickFunc(button_gesture_event_start_long_press, dev->_function_context);
			button_gesture_new_state(dev, button_gesture_state_OCS_PRESS);
		}
		break;
	
	//---------------------------------------
	case button_gesture_state_OCS_UP:
		// level is inactive

		if ((activeLevel) && (waitTime < dev->_debounceTicks))
		{
			// button was pressed to quickly so I assume some bouncing.
			button_gesture_new_state(dev, dev->_lastState); // go back
		} 
		else if (waitTime >= dev->_debounceTicks) 
		{
			// count as a short button down
			dev->_nClicks++;
			button_gesture_new_state(dev, button_gesture_state_OCS_COUNT);
		} // if
		break;
	
	//---------------------------------------
	case button_gesture_state_OCS_COUNT:
		// debounce time is over, count clicks

		if (activeLevel) 
		{
			// button is down again
			button_gesture_new_state(dev, button_gesture_state_OCS_DOWN);
			dev->_startTime = now; // remember starting time
		} 
		else if ((waitTime > dev->_clickTicks) || (dev->_nClicks == dev->_maxClicks))
		{
			// now we know how many clicks have been made.
			if (dev->_nClicks == 1)
			{
				// this was 1 click only.
				if (dev->_paramClickFunc) dev->_paramClickFunc(button_gesture_event_click, dev->_function_context);
			} 
			else if (dev->_nClicks == 2) 
			{
				// this was a 2 click sequence.
				if (dev->_paramClickFunc) dev->_paramClickFunc(button_gesture_event_double_click, dev->_function_context);
			} 
			else 
			{
				// this was a multi click sequence.
				if (dev->_paramClickFunc) dev->_paramClickFunc(button_gesture_event_multi_click, dev->_function_context);
			} // if

			button_gesture_reset(dev);
		} // if
		break;
	
	//---------------------------------------
	case button_gesture_state_OCS_PRESS:
		// waiting for menu pin being release after long press.

		if (!activeLevel)
		{
			button_gesture_new_state(dev, button_gesture_state_OCS_PRESSEND);
			dev->_startTime = now;
		}
		else
		{
			// still the button is pressed
			if (dev->_paramClickFunc) dev->_paramClickFunc(button_gesture_event_during_long_press, dev->_function_context);
		}
		break;

	//---------------------------------------
	case button_gesture_state_OCS_PRESSEND:
		// button was released.

		if ((activeLevel) && (waitTime < dev->_debounceTicks))
		{
			// button was released to quickly so I assume some bouncing.
			button_gesture_new_state(dev, dev->_lastState); // go back
		} 
		else if (waitTime >= dev->_debounceTicks) 
		{
			if (dev->_paramClickFunc) dev->_paramClickFunc(button_gesture_event_stop_long_press, dev->_function_context);
			button_gesture_reset(dev);
		}
		break;

	//---------------------------------------
	default:
		// unknown state detected -> reset state machine
		button_gesture_new_state(dev, button_gesture_state_OCS_INIT);
		break;
	}
}

//================================================================
int button_gesture_get_number_clicks(button_gesture_st* dev)
{
	return dev->_nClicks;
}

//================================================================
bool button_gesture_is_idle(button_gesture_st* dev)
{ 
	return dev->_state == button_gesture_state_OCS_INIT; 
}

//================================================================
bool button_gesture_is_long_pressed(button_gesture_st* dev) 
{ 
	return dev->_state == button_gesture_state_OCS_PRESS; 
}
