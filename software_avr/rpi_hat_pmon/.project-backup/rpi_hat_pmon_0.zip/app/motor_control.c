/*
 * motor_control.c
 *
 * Created: 20/07/2022 8:24:45
 *  Author: David Michaeli / CaribouLabs LTD
 */ 

#include <atmel_start.h>
#include "motor_control.h"

//=========================================================
void motor_control_init(motor_control_st *dev)
{
	// mode = PWM (on in1, in2 pins)
	MODE_set_level(false);
	MODE_set_dir(PORT_DIR_OUT);
	
	IN1_PH_set_dir(PORT_DIR_OUT);
	IN2_EN_set_dir(PORT_DIR_OUT);
	
	motor_control_set_mode(dev, motor_low_power, 0);
	dev->initialized = true;
}

//=========================================================
void motor_control_set_mode(motor_control_st *dev, motor_control_mode_en mode, uint8_t speed)
{
	if (!dev->initialized) return;
	
	dev->mode = mode;
	dev->speed = speed;
	
	// setup low power
	switch (mode)
	{	
		case motor_forward: MODE_set_level(true); IN1_PH_set_level(true); IN2_EN_set_level(false); break;
		case motor_reverse: MODE_set_level(true); IN1_PH_set_level(false); IN2_EN_set_level(true); break;
		case motor_break: MODE_set_level(true); IN1_PH_set_level(true); IN2_EN_set_level(true); break;
		case motor_low_power: 
		default:
			MODE_set_level(false); 
			IN1_PH_set_level(false); 
			IN2_EN_set_level(false); 
		break;
	}
}