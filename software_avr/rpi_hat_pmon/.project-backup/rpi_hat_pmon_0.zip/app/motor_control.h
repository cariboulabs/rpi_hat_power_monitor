/*
 * motor_control.h
 *
 * Created: 20/07/2022 8:24:23
 *  Author: David Michaeli / CaribouLabs LTD
 */ 


#ifndef MOTOR_CONTROL_H_
#define MOTOR_CONTROL_H_


typedef enum
{
	motor_low_power = 0,
	motor_forward = 1,
	motor_reverse = 2,
	motor_break = 3,
} motor_control_mode_en;

typedef struct  
{
	motor_control_mode_en mode;
	uint8_t speed;
	bool initialized;
} motor_control_st;

void motor_control_init(motor_control_st *dev);
void motor_control_set_mode(motor_control_st *dev, motor_control_mode_en mode, uint8_t speed);


#endif /* MOTOR_CONTROL_H_ */