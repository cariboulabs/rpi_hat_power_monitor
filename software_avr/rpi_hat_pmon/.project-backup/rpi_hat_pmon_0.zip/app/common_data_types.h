/*
 * common_data_types.h
 *
 * Created: 01/01/2022 16:01:33
 *  Author: David Michaeli / CaribouLabs LTD
 */ 

#ifndef COMMON_DATA_TYPES_H_
#define COMMON_DATA_TYPES_H_

//----------------------------------------------------
// DEFINITIONS
//----------------------------------------------------
typedef enum
{
	// common
	OPCODE_PING = 0,
	DEBUG_IF_RESERVED_CODES_MAX = 19,
	
	// reports
	OPCODE_SENSOR_DATA_REPORT = 20,
	OPCODE_GET_RECORDS = 21,
	OPCODE_VERSIONS_REQUEST = 22,
	OPCODE_VERSIONS = 23,	
	
	// commands
	OPCODE_ACTUATORS_COMMAND = 40,
	OPCODE_SET_FSM_STATE = 41,
} OPCODE_en;


#define SOFTWARE_VERSION		0x01
#define SOFTWARE_SUBVERSION		0x00

//----------------------------------------------------
// INTERFACE MESSAGES
//----------------------------------------------------
#pragma pack(1)

//----------------------------------------------------
// STATUS REPORTS
typedef struct
{
	// analog inputs
	float sys_temp;
	float voltage;
	float current;
	float power;
	uint8_t button_state;
	uint8_t battery_chrg_state;
	uint8_t pg_state;
	uint8_t system_state;
	uint8_t recorder_cur_status;
	uint8_t recorder_volt_status;
} sensor_data_status_st;

typedef struct  
{
	uint16_t id;
	uint16_t len;
	uint8_t volt_vec[120];
	uint8_t cur_vec[120];
} sensor_recording_st;

typedef struct
{
	uint8_t version;
	uint8_t subversion;
	uint32_t mcu_type;
	uint8_t uuid[16];
} versions_st;

typedef enum
{
	actuator_low_power = 0,
	actuator_forward = 1,
	actuator_reverse = 2,
	actuator_break = 3	
} actuator_mode_en;

//----------------------------------------------------
// CONTROLS
typedef struct  
{
	uint8_t motor_mode;		// complies with actuator_mode_en
	uint8_t motor_speed;	// currently not availiable - only full speed
			
	uint8_t led0_state;
	uint8_t led1_state;
} actuator_command_st;

#pragma pack()

#endif /* COMMON_DATA_TYPES_H_ */