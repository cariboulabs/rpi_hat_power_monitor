/*
 * app.c
 *
 * Created: 02/07/2022 21:59:44
 *  Author: David Michaeli / CaribouLabs LTD
 */ 

#include "app.h"
#include <atomic.h>

app_st sys = 
{
	.versions = {.version = SOFTWARE_VERSION, .subversion = SOFTWARE_SUBVERSION,},
	.recording = false,
	.state = system_status_idle,
};	

//=========================================================================================
void register_timed_task(system_timed_task_st* task, uint32_t period, timed_task_callback_t cb, void* context)
{
	task->cb = cb;
	task->context = context;
	task->trigger = false;
	task->cur_counter = 0;
	task->period = period;
}

//=========================================================================================
void timed_task_tick(system_timed_task_st* task)
{
	task->cur_counter ++;
	if (task->cur_counter >= task->period)
	{
		task->cur_counter = 0;
		task->trigger = true;
	}
}

//=========================================================================================
void timed_task_fetch(system_timed_task_st* task)
{
	if (task->trigger)
	{
		task->trigger = false;
		if (task->cb) task->cb(task->context);
	}
}

//=========================================================================================
void debug_if_callback(OPCODE_en opcode, void* data, uint32_t len, void* context)
{
	app_st* s = (app_st*)context;
	
	switch(opcode)
	{
		//---------------------------------------------------------------------
		case OPCODE_VERSIONS_REQUEST:
		{
			debug_if_send_message(OPCODE_VERSIONS, (uint8_t*)&s->versions, sizeof(versions_st));
		}
		break;
		
		// commands
		//---------------------------------------------------------------------
		case OPCODE_ACTUATORS_COMMAND:
		{
			actuator_command_st *msg = (actuator_command_st*)data;
			
			if (msg->motor_mode != 255)
			{
				switch((actuator_mode_en)(msg->motor_mode))
				{
					case actuator_forward: motor_control_set_mode(&s->motor, motor_forward, msg->motor_speed); break;
					case actuator_reverse: motor_control_set_mode(&s->motor, motor_reverse, msg->motor_speed); break;
					case actuator_break: motor_control_set_mode(&s->motor, motor_break, msg->motor_speed); break;
					case actuator_low_power:
					default: motor_control_set_mode(&s->motor, motor_low_power, msg->motor_speed); break;
				}
			}
			
			if (msg->led0_state != 255) leds_set_blink(&s->leds, led0, msg->led0_state*10, 1, 0);
			if (msg->led1_state != 255) leds_set_blink(&s->leds, led0, msg->led1_state*10, 1, 0);
		}
		break;
		
		//---------------------------------------------------------------------
		case OPCODE_SET_FSM_STATE:
		{
			system_status_en* state = (system_status_en*)data;
			s->state = *state;
		}
		break;

		//---------------------------------------------------------------------
		default: break;
	}
}

//=========================================================================================
void update_state_operations(app_st* s)
{
	if (s->sensor_data.battery_chrg_state)
	{
		leds_set_blink(&s->leds, led0, 5, 95, 0);
		leds_set_blink(&s->leds, led1, 5, 95, 50);
		
		return;
	}
	
	switch (s->state)
	{
		//--------------------------------------
		case system_status_stretching:
			leds_set_blink(&s->leds, led0, 25, 25, 0);
			leds_set_blink(&s->leds, led1, 25, 25, 50);
			motor_control_set_mode(&s->motor, motor_forward, 1);
		break;
		
		//--------------------------------------
		case system_status_releasing:
			leds_set_blink(&s->leds, led0, 5, 95, 0);
			leds_set_blink(&s->leds, led1, 5, 95, 0);
			motor_control_set_mode(&s->motor, motor_reverse, 1);
		break;
		
		//--------------------------------------
		case system_status_stretching_pause:
		case system_status_releasing_pause:
		case system_status_holding:
			leds_set_state(&s->leds, led0, true);
			leds_set_state(&s->leds, led1, true);
			motor_control_set_mode(&s->motor, motor_break, 1);
		break;
		
		//--------------------------------------
		case system_status_idle:
		default:
			leds_set_state(&s->leds, led0, false);
			leds_set_state(&s->leds, led1, false);
			motor_control_set_mode(&s->motor, motor_low_power, 1);
		break;
	}
}

//=========================================================================================
void button_gesture_event(button_gesture_event_en ev, void* context)
{
	app_st* s = (app_st*)context;
	
	// if charging - don't do anything
	if (s->sensor_data.battery_chrg_state)
	{	
		// todo	
	}
	
	// if not charging
	switch (s->state)
	{
		//--------------------------------------
		case system_status_idle: 
			if (ev == button_gesture_event_double_click)
			{
				// Change state to "Stretching"
				s->state = system_status_stretching;
			}
			break;
			
		//--------------------------------------
		case system_status_stretching:
			if (ev == button_gesture_event_click)
			{
				// Change state to "Pause Stretching"
				s->state = system_status_stretching_pause;
			}
			else if (ev == button_gesture_event_during_long_press)
			{
				// Change state to "Releasing"
				s->state = system_status_releasing;
			}
			break;
			
		//--------------------------------------
		case system_status_releasing:
			if (ev == button_gesture_event_click)
			{
				// Change state to "Pause Releasing"
				s->state = system_status_releasing_pause;
			}
			else if (ev == button_gesture_event_double_click)
			{
				// Change state to "Stretching"
				s->state = system_status_stretching;
			}
			break;
		
		//--------------------------------------
		case system_status_stretching_pause:
			if (ev == button_gesture_event_click)
			{
				// Change state to "Stretching"
				s->state = system_status_stretching;
			}
			else if (ev == button_gesture_event_during_long_press)
			{
				// Change state to "Releasing"
				s->state = system_status_releasing;
			}
			break;
		
		//--------------------------------------
		case system_status_releasing_pause:
			if (ev == button_gesture_event_click)
			{
				// Change state to "Releasing"
				s->state = system_status_releasing;
			}
			else if (ev == button_gesture_event_double_click)
			{
				// Change state to "Stretching"
				s->state = system_status_stretching;
			}
			break;
		
		//--------------------------------------
		case system_status_holding:
			break;
		
		//--------------------------------------
		default:
			break;
	}
}

//=========================================================================================
void charge_state_event(void *pin, bool new_val, uint8_t details, void* context)
{
	app_st* s = (app_st*)context;
	s->sensor_data.battery_chrg_state = !new_val;
}

//=========================================================================================
void power_good_event(void *pin, bool new_val, uint8_t details, void* context)
{
	app_st* s = (app_st*)context;
	s->sensor_data.pg_state = new_val;
}

//=========================================================================================
void button_low_level_event(void *pin, bool new_val, uint8_t details, void* context)
{
	app_st* s = (app_st*)context;
	
	// negative logic on the button pressing
	s->sensor_data.button_state = (new_val == 0);
}

//=========================================================================================
void send_sensor_report_handler(void* context)
{
	app_st* s = (app_st*)context;
	
	// update the system state in the sensor_data
	s->sensor_data.system_state = (uint8_t)s->state;
	s->sensor_data.recorder_cur_status = recorder_status(&s->rec_current);
	s->sensor_data.recorder_volt_status = recorder_status(&s->rec_voltage);
	
	// send the report
	debug_if_send_message(OPCODE_SENSOR_DATA_REPORT, (uint8_t*)&s->sensor_data, sizeof(sensor_data_status_st));
}

//=========================================================================================
void recording_task_handler(void* context)
{
	app_st* s = (app_st*)context;
	
	if (s->recording)
	{
		// this value should be positive
		uint8_t rec_val = 0;
		
		if (s->sensor_data.voltage >= 0) rec_val = (s->sensor_data.voltage * 15.0f);
		recorder_rec_val(&s->rec_voltage, rec_val);
		
		if (s->sensor_data.current >= 0) rec_val = (s->sensor_data.current * 200.0f);
		recorder_rec_val(&s->rec_current, rec_val);
	}
}

//=========================================================================================
void timer_callback(uint32_t time, void* context)
{
	app_st* s = (app_st*)context;
	
	// tick the button
	button_gesture_tick_level(&s->button_gesture, SW_get_level());
	
	// state machine
	update_state_operations(s);
	
	// tick the leds
	leds_tick(&s->leds);
	
	// scheduling
	timed_task_tick(&s->send_report_task);
}

//=========================================================================================
void temperature_callback(void* p, void* context)
{
	analog_value_st* point = (analog_value_st*)p;
	app_st* s = (app_st*)context;
	s->sensor_data.sys_temp = point->value;
}

//=========================================================================================
void voltage_callback(void* p, void* context)
{
	analog_value_st* point = (analog_value_st*)p;
	app_st* s = (app_st*)context;
	s->sensor_data.voltage = point->value;
	s->sensor_data.power = s->sensor_data.voltage * s->sensor_data.current;
}

//=========================================================================================
void current_callback(void* p, void* context)
{
	analog_value_st* point = (analog_value_st*)p;
	app_st* s = (app_st*)context;
	s->sensor_data.current = point->value;
	s->sensor_data.power = s->sensor_data.voltage * s->sensor_data.current;
}

//=========================================================================================
void app(void)
{
	// Get Sigrow
	init_system_data(&sys.versions.mcu_type, sys.versions.uuid);
	
	// initialize the LEDs
	leds_init(&sys.leds, true);
	
	// setup the motor
	motor_control_init(&sys.motor);	

	// debug interface
	debug_if_init(debug_if_callback, &sys);
	debug_if_send_ping;

	// initialize the periodic timer
	timer_init(10, timer_callback, &sys);
	
	// extint low level events
	extint_register(extint_pin_button, button_low_level_event, &sys);
	extint_register(extint_pin_bat_stat, charge_state_event, &sys);
	extint_register(extint_pin_pg, power_good_event, &sys);
	
	// init button gesture
	button_gesture_init(&sys.button_gesture, false);
	button_gesture_set_debounce_ticks(&sys.button_gesture, timer_get_ticks_from_millisec(50));
	button_gesture_set_click_ticks(&sys.button_gesture, timer_get_ticks_from_millisec(500));
	button_gesture_set_press_ticks(&sys.button_gesture, timer_get_ticks_from_millisec(2000));
	button_gesture_attachClick(&sys.button_gesture, button_gesture_event, &sys);

	// initialize analog sensors
	analog_sense_init();
	analog_sense_points_st* sens_points = analog_sense_get_points();
	analog_read_register(&sens_points->temperature, temperature_callback, &sys);
	analog_read_register(&sens_points->voltage, voltage_callback, &sys);
	analog_read_register(&sens_points->current, current_callback, &sys);
	
	// timed tasks registration
	register_timed_task(&sys.send_report_task, timer_get_ticks_from_millisec(250), send_sensor_report_handler, &sys);
	register_timed_task(&sys.recording_task, timer_get_ticks_from_millisec(40), recording_task_handler, &sys);
	
	// initial states of IOs
	sys.sensor_data.battery_chrg_state = !VBAT_STAT_get_level();
	sys.sensor_data.pg_state = PG_get_level();
	sys.sensor_data.button_state = !SW_get_level();
	
	// main loop
	sys_main_loop();
}

//=========================================================================================
void sys_main_loop(void)
{
	while (true)
	{
		timed_task_fetch(&sys.send_report_task);
		timed_task_fetch(&sys.recording_task);
	}
}