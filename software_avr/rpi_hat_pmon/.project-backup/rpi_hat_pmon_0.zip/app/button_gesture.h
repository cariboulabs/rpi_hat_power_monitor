/*
 * button_gesture.h
 *
 * Created: 19/07/2022 11:53:51
 *  Author: David Michaeli / CaribouLabs LTD
 */ 


#ifndef BUTTON_GESTURE_H_
#define BUTTON_GESTURE_H_

#include <stdio.h>
#include <stdbool.h>

typedef enum
{
	button_gesture_state_OCS_INIT = 0,
	button_gesture_state_OCS_DOWN = 1,
	button_gesture_state_OCS_UP = 2,
	button_gesture_state_OCS_COUNT = 3,
	button_gesture_state_OCS_PRESS = 6,
	button_gesture_state_OCS_PRESSEND = 7,
	button_gesture_state_UNKNOWN = 99
}  button_gesture_state_machine_en;

typedef enum
{
	button_gesture_event_click = 0,
	button_gesture_event_double_click = 1,
	button_gesture_event_multi_click = 2,
	button_gesture_event_start_long_press = 3,
	button_gesture_event_stop_long_press = 4,
	button_gesture_event_during_long_press = 5,
} button_gesture_event_en;

typedef void (*button_gesture_cb)(button_gesture_event_en ev, void* context);

typedef struct  
{
	unsigned int _currentTimeTicks;
	unsigned int _debounceTicks; // number of ticks for debounce times.
	unsigned int _clickTicks;   // number of msecs before a click is detected.
	unsigned int _pressTicks;   // number of msecs before a long button press is detected
	bool _activeState;

	button_gesture_cb _paramClickFunc;
	void *_function_context;

	button_gesture_state_machine_en _state;
	button_gesture_state_machine_en _lastState;

	unsigned long _startTime; // start of current input change to checking debouncing
	int _nClicks;             // count the number of clicks with this variable
	int _maxClicks;       // max number (1, 2, multi=3) of clicks of interest by registration of event functions.
} button_gesture_st;

void button_gesture_init(button_gesture_st* dev, bool active_state);
void button_gesture_reset(button_gesture_st* dev);
void button_gesture_set_debounce_ticks(button_gesture_st* dev, int ticks);
void button_gesture_set_click_ticks(button_gesture_st* dev, int ticks);
void button_gesture_set_press_ticks(button_gesture_st* dev, int ticks);
void button_gesture_attachClick(button_gesture_st* dev, button_gesture_cb newFunction, void *parameter);
void button_gesture_tick_level(button_gesture_st* dev, bool level);
int button_gesture_get_number_clicks(button_gesture_st* dev);
bool button_gesture_is_idle(button_gesture_st* dev);
bool button_gesture_is_long_pressed(button_gesture_st* dev);

#endif /* BUTTON_GESTURE_H_ */