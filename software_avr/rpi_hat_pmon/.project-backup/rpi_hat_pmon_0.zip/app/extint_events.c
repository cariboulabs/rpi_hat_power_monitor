/*
 * extint_events.h
 *
 * Created: 03/07/2022 9:06:54
 *  Author: David Michaeli / CaribouLabs LTD
 */ 

#include "extint_events.h"
#include "timer.h"


extint_registry_st extint = 
{
	.button_int = {
		// PORT F
		.pin = 5,
		.pin_value = -1,
		.sens = extint_sens_both,
		.cb = NULL,
		.context = NULL,
		.event_time_tick = 0,
	},
	
	.pg_int = {
		// PORT F
		.pin = 3,
		.pin_value = -1,
		.sens = extint_sens_both,
		.cb = NULL,
		.context = NULL,
		.event_time_tick = 0,
	},
	
	.bat_stat_int = {
		// PORT F
		.pin = 4,
		.pin_value = -1,
		.sens = extint_sens_both,
		.cb = NULL,
		.context = NULL,
		.event_time_tick = 0,
	},
};


#define EXTINT_CHECK_PIN(p,f,d,t)	if ((p).sens != extint_sens_none)											\
									{																						\
										bool last_pin_val = (p).pin_value;													\
										bool cur_pin_val = (f);																\
										(p).event_time_tick = (t);															\
										if (((p).sens == extint_sens_both && last_pin_val != cur_pin_val) ||				\
										((p).sens == extint_sens_rising && cur_pin_val > last_pin_val) ||					\
										((p).sens == extint_sens_falling && cur_pin_val < last_pin_val))					\
										{																					\
											if ((p).cb != NULL)																\
											{																				\
												(p).cb(&(p), cur_pin_val, d, (p).context);									\
											}																				\
										}																					\
										(p).pin_value = cur_pin_val;														\
									}


//=========================================================================================
void extint_event_port_f(void)
{
	uint32_t event_tick = timer_get_time_short();

	EXTINT_CHECK_PIN(extint.button_int,SW_get_level(),0,event_tick);
	EXTINT_CHECK_PIN(extint.pg_int,PG_get_level(),0,event_tick);
	EXTINT_CHECK_PIN(extint.bat_stat_int,VBAT_STAT_get_level(),0,event_tick);
}

//=========================================================================================
void extint_register(extint_pin_en pin_type, extint_callback_t cb, void* context)
{
	switch(pin_type)
	{
		case extint_pin_button:
			extint.button_int.cb = cb;
			extint.button_int.context = context;	
			break;
			
		case extint_pin_pg:
			extint.pg_int.cb = cb;
			extint.pg_int.context = context;
			break;
			
		case extint_pin_bat_stat:
			extint.bat_stat_int.cb = cb;
			extint.bat_stat_int.context = context;
			break;
			
		default: break;
	}
}

